import axios from 'axios'

const instance = axios.create({
  baseURL:"https://wd5502850646lszzwb.wilddogio.com"
})

// instance.defaults.headers.common['SOMETHING'] = 'SOMETHING'

export default instance