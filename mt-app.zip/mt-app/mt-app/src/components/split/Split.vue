<template>
	<div class="split"></div>
</template>

<script>
	export default {}
</script>

<style>
	.split{
		width: 100%;
		height: 10px;
		background: #F4F4F4;
	}
</style>